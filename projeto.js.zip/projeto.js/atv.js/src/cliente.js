// Classe Cliente
class Cliente {

    constructor(id, nome, telefone, email) {
        this.id = id;
        this.nome = nome;
        this.telefone = telefone;
        this.email = email;
    }

    // Atualiza os dados do cliente
    atualizar(nome, telefone, email) {
        this.nome = nome;
        this.telefone = telefone;
        this.email = email;
    }

    // Exibe os dados do cliente
    consultarDados() {
        return {
            id: this.id,
            nome: this.nome,
            telefone: this.telefone,
            email: this.email
        };
    }
}
module.exports = Cliente