// Classe Profissional
class Profissional {

    constructor(id, nome, servico) {
        this.id = id;
        this.nome = nome;
        this.servico = servico;
        this.disponivel = true;
    }

    // Altera a disponibilidade do profissional
    alterarDisponibilidade(disponivel) {
        this.disponivel = disponivel;
    }

    // Atualiza os dados do profissional
    atualizar(nome, servico) {
        this.nome = nome;
        this.servico = servico;
    }

    // Verifica se o profissional está disponível
    verificarDisponibilidade() {
        return this.disponivel;
    }
}
module.exports = Profissional