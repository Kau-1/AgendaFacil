class Agenda {
    constructor() {
        this.agendamentos = []
    }
    cadastrar(agendamento) {
         if(!(agendamento instanceof require("./agendamento.js"))){
            throw new Error("Somente agendamentos podem ser cadastrados");
            
        }
        if(this.agendamentos.some(a => a.id === agendamento.id)){
            throw new Error("Já existe um agendamento com esse ID");
            
        }

        this.agendamentos.push(agendamento)
    }
}
module.exports = Agenda