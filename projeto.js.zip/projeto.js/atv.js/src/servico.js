 // Classe Especialidade
class Servico {

    constructor(id, nome, descricao, valor) {
        this.id = id;
        this.valor = valor
        this.nome = nome;
        this.descricao = descricao;
    }

    // Atualiza os dados da especialidade
    atualizar(nome, descricao, valor) {
        this.nome = nome;
        this.valor = valor
        this.descricao = descricao;
    }

    // Consulta os dados da especialidade
    consultarDados() {
        return {
            id: this.id,
            valor: this.valor,
            nome: this.nome,
            descricao: this.descricao
        };
    }
}
module.exports = Servico