
class Agendamento {

    constructor(id, cliente, profissional, data, horario) {
        this.id = id;
        this.cliente = cliente;
        this.profissional = profissional;
        this.data = data;
        this.horario = horario;
        this.status = "Agendado";
    }

    // Cancela o agendamento
    cancelar() {
        if (this.status === "Cancelado") {
            throw new Error("Agendamento já está cancelado.");
        }

        this.status = "Cancelado";
    }

    // Finaliza o atendimento
    finalizar() {
        if (this.status === "Cancelado") {
            throw new Error(
                "Não é possível finalizar um agendamento cancelado."
            );
        }

        this.status = "Concluído";
    }

    // Atualiza a data e o horário
    atualizar(data, horario) {
        if (this.status === "Cancelado") {
            throw new Error(
                "Não é possível atualizar um agendamento cancelado."
            );
        }

        this.data = data;
        this.horario = horario;
    }
}
module.exports = Agendamento