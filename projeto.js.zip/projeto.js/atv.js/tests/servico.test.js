const Servico = require("../src/servico.js")
describe('Classe servico', () => {
let servico;

    beforeEach(() => {
        servico = new Servico(
            "id", "nome", "servico"
        );
    });
test('deve criar uma instância de um servico', () => {
            expect(servico).toBeInstanceOf(Servico);
        });

         test('deve possuir a propriedade id', () => {
            expect(Object.hasOwn(servico, "id")).toBe(true);
        });

        test('deve possuir a propriedade nome', () => {
            expect(Object.hasOwn(servico, "nome")).toBe(true);
        });

        
        test('deve possuir a propriedade valor', () => {           
            expect(Object.hasOwn(servico, "valor")).toBe(true);
        });
         test('deve possuir a propriedade nome', () => {
            expect(Object.hasOwn(servico, "descricao")).toBe(true);
        });
        test('deve possuir os métodos definidos pelo sistema', () => {
            expect(
                typeof servico.atualizar
            ).toBe('function');

            expect(
                typeof servico.consultarDados
            ).toBe('function');

           
        });
    })