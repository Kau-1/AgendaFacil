const Cliente = require("../src/cliente.js")
describe('Classe cliente', () => {
let cliente;

    beforeEach(() => {
        cliente = new Cliente(
            "id", "nome", "telefone", "email"
        );
    });
test('deve criar uma instância de um cliente', () => {
            expect(cliente).toBeInstanceOf(Cliente);
        });

         test('deve possuir a propriedade id', () => {
            expect(Object.hasOwn(cliente, "id")).toBe(true);
        });

        test('deve possuir a propriedade nome', () => {
            expect(Object.hasOwn(cliente, "nome")).toBe(true);
        });

        test('deve possuir a propriedade telefone', () => {
            expect(Object.hasOwn(cliente, "telefone")).toBe(true);
        })
        test('deve possuir a propriedade email', () => {
            expect(Object.hasOwn(cliente, "email")).toBe(true);
        });
    })