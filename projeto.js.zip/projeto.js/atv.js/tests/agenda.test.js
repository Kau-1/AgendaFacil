const Agenda = require("../src/agenda")
const Agendamento = require("../src/agendamento")
const Cliente = require("../src/cliente")
const Profissional = require("../src/profissional")
const Servico = require("../src/servico")

describe('Classe Agenda', () => {
    let cliente
    let profissional
    let servico
    let agendamento
    let agenda

    beforeEach(() => {
        cliente = new Cliente(
            '01', "nome", "telefone", "email"
        );

        servico = new Servico(
           "id", "nome", "descricao", 100
        );

        profissional = new Profissional(
          "id", "nome", servico

        );
        agendamento = new Agendamento("01", cliente, profissional, "09/10/26", "19:43")
        agenda = new Agenda()
    });
     describe('Cadastro de agendamento', () => {
        test('deve cadastrar um agendamento', () => {
            agenda.cadastrar(agendamento)

            expect(agenda.agendamentos).toContain(
                agendamento
            );
        });

        test('deve permitir cadastrar varios agendamentos', () => {
            const agendamento2 = new Agendamento("02", cliente, profissional, "10/10/26", "19:43")
            agenda.cadastrar(agendamento);
            agenda.cadastrar(agendamento2)

            expect(agenda.agendamentos).toHaveLength(2);
        });

         test('deve rejeitar um objeto que não seja um agendamento', () => {
            expect(() => {
                agenda.cadastrar({
                    id: 'age-001'
                });
            }).toThrow(
                'Somente agendamentos podem ser cadastrados'
            );
        });

         test('não deve cadastrar ID duplicado', () => {
             agenda.cadastrar(agendamento)

           
            expect(() => {
                agenda.cadastrar(agendamento)
            }).toThrow(
                'Já existe um agendamento com esse ID'
            );
        });
    });


})