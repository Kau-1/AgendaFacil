const Profissional = require("../src/profissional.js")
describe('Classe profissional', () => {
let profissional;

    beforeEach(() => {
        profissional = new Profissional(
            "id", "nome", "servico"
        );
    });
test('deve criar uma instância de um profissional', () => {
            expect(profissional).toBeInstanceOf(Profissional);
        });

         test('deve possuir a propriedade id', () => {
            expect(Object.hasOwn(profissional, "id")).toBe(true);
        });

        test('deve possuir a propriedade nome', () => {
            expect(Object.hasOwn(profissional, "nome")).toBe(true);
        });

        
        test('deve possuir a propriedade servico', () => {           
            expect(Object.hasOwn(profissional, "servico")).toBe(true);
        });
    })